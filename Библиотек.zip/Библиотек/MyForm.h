#pragma once

// Отключаем проблемные заголовки
#define _CRT_SECURE_NO_WARNINGS

#include <vector>
#include <string>
#include <msclr/marshal_cppstd.h>

using namespace System;
using namespace System::Windows::Forms;
using namespace System::Drawing;

namespace LibrarySystem {

    public ref class Book {
    public:
        int id;
        String^ title;
        int clientId;
        Book(int i, String^ t, int c) : id(i), title(t), clientId(c) {}
    };

    public ref class Client {
    public:
        int id;
        String^ lastName;
        String^ firstName;
        String^ middleName;
        Client(int i, String^ l, String^ f, String^ m) : id(i), lastName(l), firstName(f), middleName(m) {}
    };

    public ref class MyForm : public Form {
    private:
        System::Collections::Generic::List<Book^>^ books;
        System::Collections::Generic::List<Client^>^ clients;
        int nextBookId, nextClientId;

        TabControl^ mainTabs;
        TabPage^ tabBooks;
        TabPage^ tabClients;
        DataGridView^ gridBooks;
        DataGridView^ gridClients;
        Button^ btnAddBook;
        Button^ btnDeleteBook;
        Button^ btnAddClient;
        Button^ btnDeleteClient;

    public:
        MyForm() {
            books = gcnew System::Collections::Generic::List<Book^>();
            clients = gcnew System::Collections::Generic::List<Client^>();
            nextBookId = 1;
            nextClientId = 1;

            // Тестовые данные
            books->Add(gcnew Book(1, "Война и мир", 0));
            books->Add(gcnew Book(2, "Преступление и наказание", 0));
            nextBookId = 3;

            clients->Add(gcnew Client(1, "Иванов", "Иван", "Иванович"));
            clients->Add(gcnew Client(2, "Петрова", "Анна", "Сергеевна"));
            nextClientId = 3;

            InitializeComponent();
        }

    private:
        void InitializeComponent() {
            this->Text = L"Библиотечная система";
            this->Size = Drawing::Size(800, 500);

            // Главный TabControl
            mainTabs = gcnew TabControl();
            mainTabs->Dock = DockStyle::Fill;

            // Вкладка Книги
            tabBooks = gcnew TabPage(L"Книги");
            gridBooks = gcnew DataGridView();
            gridBooks->Dock = DockStyle::Top;
            gridBooks->Height = 350;
            gridBooks->ReadOnly = true;

            btnAddBook = gcnew Button();
            btnAddBook->Text = L"Добавить книгу";
            btnAddBook->Dock = DockStyle::Bottom;
            btnAddBook->Click += gcnew EventHandler(this, &MyForm::OnAddBook);

            btnDeleteBook = gcnew Button();
            btnDeleteBook->Text = L"Удалить книгу";
            btnDeleteBook->Dock = DockStyle::Bottom;
            btnDeleteBook->Click += gcnew EventHandler(this, &MyForm::OnDeleteBook);

            tabBooks->Controls->Add(btnDeleteBook);
            tabBooks->Controls->Add(btnAddBook);
            tabBooks->Controls->Add(gridBooks);

            // Вкладка Клиенты
            tabClients = gcnew TabPage(L"Клиенты");
            gridClients = gcnew DataGridView();
            gridClients->Dock = DockStyle::Top;
            gridClients->Height = 350;
            gridClients->ReadOnly = true;

            btnAddClient = gcnew Button();
            btnAddClient->Text = L"Добавить клиента";
            btnAddClient->Dock = DockStyle::Bottom;
            btnAddClient->Click += gcnew EventHandler(this, &MyForm::OnAddClient);

            btnDeleteClient = gcnew Button();
            btnDeleteClient->Text = L"Удалить клиента";
            btnDeleteClient->Dock = DockStyle::Bottom;
            btnDeleteClient->Click += gcnew EventHandler(this, &MyForm::OnDeleteClient);

            tabClients->Controls->Add(btnDeleteClient);
            tabClients->Controls->Add(btnAddClient);
            tabClients->Controls->Add(gridClients);

            mainTabs->TabPages->Add(tabBooks);
            mainTabs->TabPages->Add(tabClients);
            this->Controls->Add(mainTabs);

            RefreshGrids();
        }

        void RefreshGrids() {
            // Книги
            gridBooks->DataSource = nullptr;
            gridBooks->DataSource = books;

            // Клиенты
            gridClients->DataSource = nullptr;
            gridClients->DataSource = clients;
        }

        void OnAddBook(Object^ sender, EventArgs^ e) {
            String^ title = Microsoft::VisualBasic::Interaction::InputBox(
                L"Название книги:", L"Добавить книгу", L"");
            if (!String::IsNullOrEmpty(title)) {
                books->Add(gcnew Book(nextBookId++, title, 0));
                RefreshGrids();
            }
        }

        void OnDeleteBook(Object^ sender, EventArgs^ e) {
            if (gridBooks->CurrentRow != nullptr) {
                Book^ b = safe_cast<Book^>(gridBooks->CurrentRow->DataBoundItem);
                books->Remove(b);
                RefreshGrids();
            }
        }

        void OnAddClient(Object^ sender, EventArgs^ e) {
            String^ first = Microsoft::VisualBasic::Interaction::InputBox(
                L"Имя:", L"Добавить клиента", L"");
            String^ last = Microsoft::VisualBasic::Interaction::InputBox(
                L"Фамилия:", L"Добавить клиента", L"");
            String^ middle = Microsoft::VisualBasic::Interaction::InputBox(
                L"Отчество:", L"Добавить клиента", L"");
            if (!String::IsNullOrEmpty(first) && !String::IsNullOrEmpty(last)) {
                clients->Add(gcnew Client(nextClientId++, last, first, middle));
                RefreshGrids();
            }
        }

        void OnDeleteClient(Object^ sender, EventArgs^ e) {
            if (gridClients->CurrentRow != nullptr) {
                Client^ c = safe_cast<Client^>(gridClients->CurrentRow->DataBoundItem);
                clients->Remove(c);
                RefreshGrids();
            }
        }
    };
}